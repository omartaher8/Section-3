---
name: Feature request
about: Suggest a feature or story
title: "As a [user], I need [feature] so that [benefit]"
labels: user-story
assignees: 
---

## Story

As a ___, I need ___ so that ___.

## Acceptance Criteria (Given/When/Then)
